import java.net.MalformedURLException;
import org.openqa.selenium.remote.DesiredCapabilities;


public class Launchgoogle
{
	public static void main(String[] args) throws MalformedURLException
	{
		DesiredCapabilities ds=new DesiredCapabilities();
		ds.setCapability(MobileCapabilityType.DEVICE_NAME, "Renuga");
		ds.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		ds.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		
		AndroidDriver driver=new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),ds);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("http://demowebshop.tricentis.com/login"); 
	}
}